package dio.me.gerenciador_de_tarefas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciadorDeTarefasApplicationTests {

	@Test
	void contextLoads() {
	}

}
